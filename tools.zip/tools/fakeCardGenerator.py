from ccNum_class import CreditCardNumber
import sys


if len(sys.argv) == 1:
    numberOfCCNumbers = input('How many fake credit cards do you want generated: ')
    numberOfCCNumbers = int(numberOfCCNumbers)
elif len(sys.argv) == 2:
    numberOfCCNumbers = int(sys.argv[1])

for i in range(0, numberOfCCNumbers):
    x = CreditCardNumber()
    x.toFormattedString()
